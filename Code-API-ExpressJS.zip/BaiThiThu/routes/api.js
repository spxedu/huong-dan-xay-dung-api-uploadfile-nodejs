var express = require('express');
var router = express.Router();
var {lay_ds, xem_chi_tiet, them_xe} = require('../controllers/xeMayController');

// http://localhost:3000/api/xemay 
router.get('/xemay', lay_ds );

// xem chi tiết
router.get('/xemay/:id', xem_chi_tiet);

router.post('/xemay', them_xe );

module.exports = router;