const {mongoose} = require('./db');
const xeMaySchema = new mongoose.Schema(
    {
        ten_xe_ph1234:{type:String, required: true},
        mau_sac_ph1234:{type:String, required: true},
        gia_ban_ph1234:{type:Number, required: true, default:0},
        mo_ta_ph1234:{type:String, required: false},
        hinh_anh_ph1234:{type:String, required: false}
    },
    {
        collection: 'XeMay'
    }
);
let XeMay = mongoose.model('XeMay', xeMaySchema);
module.exports = {XeMay}
